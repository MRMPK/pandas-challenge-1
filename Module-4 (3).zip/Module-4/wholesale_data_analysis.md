
# Wholesale Data Analysis

This project contains an analysis of wholesale order data, focusing at generating insights for client and product performance, profit calculations, and shipping costs.

## Project Structure

The analysis is structured into the following parts:

### Explore the Data

- Initial inspection of the dataset.
- Overview of the top clients and product categories.
- Calculation of key statistics such as total units ordered.

### Transform the Data

- Subtotal calculation for each order (`unit_price * quantity`).
- Shipping price calculation based on item weight.
- Total price, line cost, and profit calculations.

### Confirm the Work

- Verification of calculated totals for selected order IDs.

### Summarize and Analyze

- Summary statistics for the top 5 clients.
- Analysis of total units purchased, shipping costs, revenue, and profit.

## Files

- `wholesale_data_analysis.ipynb`: Jupyter notebook containing the full analysis.
- `client_dataset.csv`: The raw dataset used for the analysis.
- `wholesale_data_analysis_starter_code.ipynb`: The starter code provided, which was modified for this analysis.

## Setup

Clone this repository.

```bash
git clone <repository-url>
```

Ensure you have the following dependencies installed:

- Python 3.x
- pandas
- numpy
- jupyter

Open the notebook in Jupyter:

```bash
jupyter notebook wholesale_data_analysis.ipynb
```


## Results

The analysis provides insights into:

- Client performance (top clients based on order volumes and profit).
- Product profitability.
- Shipping cost contributions.
- Profit margins for each order.

